
<!doctype HTML>
<html>
   <head>
      <meta charset="utf-8">
      <title>Kõnekeskus</title>
      <link rel="stylesheet" href="stiilid.css">
      <script src="skript.js"></script>
   </head>
   <body>
      <h1>Kõnekeskus</h1>
      <form method="post" action="<?= $_SERVER['PHP_SELF']?>">
         <input type="hidden" name="action" value="logout">
         <button type="submit">Logi välja</button>
      </form>
      <br>
      <form id="lisa-vorm" method="post" action="<?= $_SERVER['PHP_SELF']; ?>">
         <input type="hidden" name="action" value="lisa">
         <table>
            <tr>
               <td valign="top"><label for="probleem">Probleemi kirjeldus:</label></td>
               <td><textarea name="kirjeldus" style="width:350px;height:50px" id="probleem" value=""></textarea></td>
            <tr>
               <td>Staatus:</td>
               <td>
                  <select name="staatus">
                     <option value=""> -- Vali nimekirjast -- </option>
                     <?php foreach (staatus_model_load() as $rida): ?>
                     <option value="<?= $rida['id']; ?>">
                        <?= htmlspecialchars($rida['nimetus']); ?>
                     </option>
                     <?php endforeach; ?>
                  </select>
               </td>
            </tr>
         </table>
         <p> <button type="submit">Lisa</button> </p>
      </form>
      <table class="probleem">
         <thead>
            <tr>
               <th>Probleemi kirjeldus</th>
               <th>Staatus</th>
               <th>Lisatud</th>
               <th>Muuda</th>
            </tr>
         </thead>
         <tbody>
            <?php
               foreach (model_load($staatus) as $rida):
               ?>
            <tr>
               <td> <?= htmlspecialchars($rida['kirjeldus']) ?> </td>
               <td> 
                  <a href="<?= $_SERVER['PHP_SELF']?>?staatus=<?= $rida['stat']?>">
                  <?= htmlspecialchars($rida['staatus']) ?> </a>
               </td>
               <td><?= htmlspecialchars($rida['lisatud']) ?></td>
               <td>
                  <form method="post" action="<?= $_SERVER['PHP_SELF']; ?>">
                     <input type="hidden" name="action" value="kustuta">
                     <input type="hidden" name="id" value="<?= $rida['id']; ?>">
                     <a href="<?= $_SERVER['PHP_SELF'] ?>?view=edit&amp;id=<?= $rida['id'] ?>" ><button type="button">Muuda infot</button></a>
                     <button type="submit" id="delete" value="delete" onclick="return confirm('Kas oled kindel?')">Kustuta</button>
                  </form>
               </td>
            </tr>
            <?php
               endforeach;
               
               ?>
         </tbody>
      </table>
      <?php if ($staatus ): ?>
      <p>
         <a href="<?= $_SERVER['PHP_SELF']?>"><button type="button">Tagasi</button></a>
      </p>
      <?php endif; ?>
   </body>
</html>
