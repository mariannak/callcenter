<?php

$host   = 'localhost';
$user   = 'test';
$pass   = 't3st3r123';
$db     = 'test';
$prefix = 'mkarm';

$link = new mysqli($host, $user, $pass, $db);
if ($link->connect_errno) {
    printf('Error: %s', $link->connect_error);
    exit();
}

if (!$link->query('SET CHARACTER SET UTF8')) {
    printf('Error: %s', $link->error);
    exit();
}

function model_load($staatus = 0)
{
    global $link, $prefix;
    
    if ($staatus) {
        $where = " WHERE probleem.staatus = '$staatus'";
    } else {
        $where = "";
        
    }
    
    $query = "SELECT
                probleem.id AS id,
                probleem.kirjeldus AS kirjeldus,
                lisatud,
                staatus.nimetus AS staatus,
                probleem.staatus AS stat
              FROM {$prefix}__probleem AS probleem
              LEFT JOIN {$prefix}__staatus AS staatus
                  ON probleem.staatus = staatus.id
              $where
              ORDER BY staatus, lisatud desc";
    
    $result = $link->query($query);
    if (!$result) {
        printf('Error: %s', $link->error);
        exit();
    }
    
    $rows = array();
    while ($row = $result->fetch_array()) {
        $rows[] = $row;
    }
    $result->close();
    
    return $rows;
}

function model_add($kirjeldus, $staatus)
{
    global $link, $prefix;
    
    $kirjeldus = $link->real_escape_string($kirjeldus);
    $staatus   = $link->real_escape_string($staatus);
    
    
    $query = "INSERT INTO {$prefix}__probleem (kirjeldus, staatus)
            VALUES ('$kirjeldus', '$staatus')";
    
    $result = $link->query($query);
    if (!$result) {
        printf('Error: %s "%s"', $link->error, $query);
        exit();
    }
    $id = $link->insert_id;
    
    return $id;
}

function model_delete($id)
{
    global $link, $prefix;
    
    $id = $link->real_escape_string($id);
    
    $query = "DELETE FROM {$prefix}__probleem WHERE id='$id' LIMIT 1";
    
    $result = $link->query($query);
    if (!$result) {
        printf('Error: %s', $link->error);
        exit();
    }
    $deleted = $link->affected_rows;
    
    return $deleted;
}

function staatus_model_load()
{
    global $link, $prefix;
    
    $query = "SELECT * FROM {$prefix}__staatus";
    
    $result = $link->query($query);
    if (!$result) {
        printf('Error: %s', $link->error);
        exit();
    }
    
    $rows = array();
    while ($row = $result->fetch_array()) {
        $rows[] = $row;
    }
    $result->close();
    
    return $rows;
}

function model_add_user($eesnimi, $perenimi, $kasutajanimi, $parool)
{
    global $link, $prefix;
    
    $hash = password_hash($parool, PASSWORD_DEFAULT);
    
    $eesnimi      = $link->real_escape_string($eesnimi);
    $perenimi     = $link->real_escape_string($perenimi);
    $kasutajanimi = $link->real_escape_string($kasutajanimi);
    $hash         = $link->real_escape_string($hash);
    
    $query = "INSERT INTO {$prefix}__kasutaja (eesnimi, perenimi, kasutajanimi, parool)
                 VALUES('$eesnimi', '$perenimi', '$kasutajanimi', '$hash')";
    
    $result = $link->query($query);
    if (!$result) {
        printf('Error: %s', $link->error);
        exit();
    }
    $id = $link->insert_id;
    
    return $id;
}

function model_get_user($kasutajanimi, $parool)
{
    global $link, $prefix;
    $kasutajanimi = $link->real_escape_string($kasutajanimi);
    $query        = "SELECT id, parool FROM {$prefix}__kasutaja
                WHERE kasutajanimi='$kasutajanimi' LIMIT 1";
    $result       = $link->query($query);
    if (!$result) {
        printf('Error: %s', $link->error);
        exit();
    }
    $kasutaja = $result->fetch_array();
    if (!$kasutaja) {
        return false;
    }
    $check_user = password_verify($parool, $kasutaja['parool']);
    if ($check_user) {
        return $kasutaja['id'];
    }
    
    return false;
}

function model_get($id)
{
    global $link, $prefix;
    
    $id = $link->real_escape_string($id);
    
    $query = "SELECT * FROM {$prefix}__probleem WHERE Id='$id' LIMIT 1";
    
    $result = $link->query($query);
    if (!$result) {
        printf('Error: %s', $link->error);
        exit();
    }
    
    $kaup = $result->fetch_array();
    $result->close();
    
    return $kaup;
}

function model_edit($id, $kirjeldus, $staatus)
{
    global $link, $prefix;
    
    $id        = $link->real_escape_string($id);
    $kirjeldus = $link->real_escape_string($kirjeldus);
    $staatus   = $link->real_escape_string($staatus);
    
    
    $query = "UPDATE {$prefix}__probleem
                SET kirjeldus='$kirjeldus',
                    staatus='$staatus'
                WHERE id='$id'
                LIMIT 1";
    
    $result = $link->query($query);
    if (!$result) {
        printf('Error: %s', $link->error);
        exit();
    }
    return $link->affected_rows;
}