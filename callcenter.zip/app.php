<?php

session_start();

require 'model.php';

require 'controller.php';


if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $result = false;

   
    switch ($_POST['action']) {

        case 'lisa':
            $kirjeldus = $_POST['kirjeldus'];
            $staatus = intval($_POST['staatus']);
            $result = controller_add($kirjeldus, $staatus);
            break;
        
        case 'muuda':
        	$id = intval($_POST['id']);
            $kirjeldus = $_POST['kirjeldus'];
            $staatus = intval($_POST['staatus']);
            
           
            $result = controller_edit($id, $kirjeldus, $staatus);
            break;

        case 'kustuta':
            $id = $_POST['id'];
            $result = controller_delete($id);
            break;

        case 'login':
            $kasutajanimi = $_POST['kasutajanimi'];
            $parool = $_POST['parool'];
            $result = controller_login($kasutajanimi, $parool);
            break;

        case 'register':
            $eesnimi = $_POST['eesnimi'];
            $perenimi = $_POST['perenimi'];
            $kasutajanimi = $_POST['kasutajanimi'];
            $parool = $_POST['parool'];
            $parool2 = $_POST['parool2'];
            $result = controller_add_user($eesnimi, $perenimi, $kasutajanimi, $parool, $parool2);
            break;

        case 'logout':
            $result = controller_logout();
            break;
    }

    if ($result) {
        header('Location: '.$_SERVER['PHP_SELF']);
    } else {
        echo 'Viga!';
    }

    exit;
}

$view = empty($_GET['view']) ? 'ccenter' : $_GET['view'];

switch ($view) {

    case 'ccenter':
        check_login();
        
        $staatus = empty($_GET['staatus']) ? 0 : intval($_GET['staatus']);
        
        require 'view_ccenter.php';
        break;
    case 'login':
        require 'view_login.php';
        break;
    case 'register':
        require 'view_register.php';
        break;
    
    case 'edit':
    	check_login();
    	$probleem = model_get($_GET['id']);
    	if ( !$probleem ){
	    	echo 'Tundmatu ID';
	    	exit;
	    }
	    require 'view_edit.php';
    	break;
        
    default:
        echo 'Viga!';
}

function check_login()
{
    if (!controller_user()) {
        header('Location: '.$_SERVER['PHP_SELF'].'?view=login');
        exit;
    }
}
