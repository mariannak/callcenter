/*jslint devel: true */
window.addEventListener('load', function () {
    "use strict";
    document.getElementById('registreeri').addEventListener('submit', function (e) {

        var parool = document.getElementById('password').value;

        if (parool.length < 6) {

            alert('Liiga lühike parool!');
            e.preventDefault();
            return;
        }
    });

});