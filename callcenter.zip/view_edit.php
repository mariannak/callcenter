<!doctype HTML>
<html>

<head>
    <meta charset="utf-8">
    <title>Kõnekeskus</title>
     <link rel="stylesheet" href="stiilid.css">
</head>

<body>
   <h1>Kõnekeskus</h1>
   <form method="post" action="<?= $_SERVER['PHP_SELF']?>">
      <input type="hidden" name="action" value="logout">
      <button type="submit">Logi välja</button>
   </form>
   <form id="lisa-vorm" method="post" action="<?= $_SERVER['PHP_SELF']; ?>">
      <input type="hidden" name="action" value="muuda">
      <input type="hidden" name="id" value="<?= $probleem['id'] ?>">
      <table>
         <tr>
            <td valign="top"><label for="probleem">Probleemi kirjeldus:</label</td>
            <td><input type="text" name="kirjeldus" id="probleem" style="width:350px"
               value="<?= htmlspecialchars($probleem['kirjeldus']) ?>"></td>
         </tr>
         <tr>
            <td>Staatus:</td>
            <td>
               <select name="staatus">
                  <option value=""> -- Vali nimekirjast -- </option>
                  <?php foreach (staatus_model_load() as $rida): ?>
                  <option value="<?= $rida['id']; ?>" 
                     <?php if($probleem['staatus'] == $rida['id']) : ?>
                     selected
                     <?php endif; ?>
                     >
                     <?= htmlspecialchars($rida['nimetus']); ?>
                  </option>
                  <?php endforeach; ?>
               </select>
            </td>
      </table>
      <p> <button type="submit">Muuda kirjet</button> 
         <button Type="button" value="Tagasi" onClick="history.go(-1);return true;">Tagasi</button>
      </p>
   </form>
</body>
</html>