<!doctype html>
<html>
   <head>
      <meta charset="utf-8">
      <title>Logi sisse</title>
      <link rel="stylesheet" href="stiilid.css">
   </head>
   <body>
      <h1>Tere tulemast kõnekeskusesse!</h1>
      <h3>Logi sisse</h3>
      <form method="post" action="<?= $_SERVER['PHP_SELF'] ?>">
         <input type="hidden" name="action" value="login">
         <table>
            <tr>
               <td><label for="user">Kasutajanimi</label></td>
               <td><input type="text" name="kasutajanimi" id="user"></td>
            </tr>
            <tr>
               <td><label for="password">Parool</label></td>
               <td><input type="password" name="parool" id="password"></td>
            </tr>
         </table>
         <button type="submit">Logi sisse</button>
      </form>
      <p>
         Ei ole kontot? <a href="<?= $_SERVER['PHP_SELF']?>?view=register">Registreeri siin</a>
      </p>
   </body>
</html>