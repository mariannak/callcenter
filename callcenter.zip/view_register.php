<!doctype html>
<html>
   <head>
      <meta charset="utf-8">
      <title>Registreeri konto</title>
      <link rel="stylesheet" href="stiilid.css">
      <script src="skript.js"></script>
   </head>
   <body>
      <h1>Kõnekeskus</h1>
      <h3>Registreeri konto</h3>
      <form id="registreeri" method="post" action="<?= $_SERVER['PHP_SELF'] ?>">
         <input type="hidden" name="action" value="register">
         <table>
            <tr>
               <td><label for="name">Eesnimi</label></td>
               <td><input type="text" name="eesnimi" id="name"></td>
            </tr>
            <tr>
               <td><label for="surname">Perekonnanimi</label></td>
               <td><input type="text" name="perenimi" id="surname"></td>
            </tr>
            <tr>
               <td><label for="user">Kasutajanimi</label></td>
               <td><input type="text" name="kasutajanimi" id="user"></td>
            </tr>
            <tr>
               <td><label for="password">Parool</label></td>
               <td><input type="password" name="parool" id="password"></td>
            </tr>
            <tr>
               <td><label for="password2">Korda parooli</label></td>
               <td><input type="password" name="parool2" id="password2"></td>
            </tr>
         </table>
         <button type="submit">Registreeri</button>
         <button type="reset">Tühjenda väljad</button>
         <button Type="button" value="Tagasi" onClick="history.go(-1);return true;">Tagasi</button>
      </form>
   </body>
</html>
